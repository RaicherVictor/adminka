package com.example.adminka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminkaApplicationTests {

    @Test
    void contextLoads() {
    }

}
